# ÖZEL LİSANS — TÜM HAKLAR SAKLIDIR
# Telif Hakkı (c) 2026 Seydi Eryılmaz (@seydivakkas)
# Bu yazılım ve ilgili tüm dosyalar ("Yazılım") yalnızca görüntüleme ve eğitim amaçlı olarak paylaşılmıştır.

"""
G050: TCP Üçlü El Sıkışma (3-Way Handshake) Analizörü ve Güvenlik Denetim Motoru.
Bu modül RFC 793 ve RFC 9293 standartlarına uygun TCP bağlantı yaşam döngüsünü,
SYN, SYN-ACK, ACK durum makinelerini, ISN güvenliğini, SYN Flood analizini ve
kural dışı bayrak kombinasyonlarını (XMAS, NULL, SYN-FIN) modeller.
"""

# Kriptografik özetleme ve HMAC işlemleri için hmac modülü
import hmac
# Kriptografik hash fonksiyonları için hashlib modülü
import hashlib
# Yapılandırılmış JSON veri işlemleri için json modülü
import json
# Dosya sistemi ve dizin yolları için os modülü
import os
# Düzenli ifade ve metin tarama için re modülü
import re
# Zaman damgaları ve zaman aşımı hesapları için time modülü
import time
# Tip denetimi ve veri yapıları için typing modülü
from typing import Dict, List, Set, Tuple, Optional, Any


class TCPValidationError(ValueError):
    """TCP paket formatı ve bayrak doğrulama hataları için özel istisna sınıfı."""
    # Standart istisna gövdesi
    pass


class TCPFlags:
    """TCP Başlık Bayrakları (Flags) ve Kural Dışı Kombinasyon Denetleyicisi."""
    # Bit 0: Bağlantıyı sonlandırma isteği (FIN - Finish)
    FIN = 0x01
    # Bit 1: Sıra numaralarını eşitleme ve bağlantı başlatma (SYN - Synchronize)
    SYN = 0x02
    # Bit 2: Bağlantıyı zorla sıfırlama / reddetme (RST - Reset)
    RST = 0x04
    # Bit 3: Alıcı tamponunu beklemeden veriyi uygulamaya iletme (PSH - Push)
    PSH = 0x08
    # Bit 4: Onay alanı geçerlidir (ACK - Acknowledgment)
    ACK = 0x10
    # Bit 5: Acil veri işaretçisi geçerlidir (URG - Urgent)
    URG = 0x20
    # Bit 6: ECN Yankı bildirimi (ECE - ECN-Echo)
    ECE = 0x40
    # Bit 7: Tıkanıklık penceresi küçültüldü bildirimi (CWR - Congestion Window Reduced)
    CWR = 0x80

    # Metin tabanlı bayrak adlarını bit maskelerine eşleyen sözlük
    FLAG_MAP: Dict[str, int] = {
        "FIN": FIN,
        "SYN": SYN,
        "RST": RST,
        "PSH": PSH,
        "ACK": ACK,
        "URG": URG,
        "ECE": ECE,
        "CWR": CWR,
    }

    @classmethod
    def encode_flags(cls, flag_list: List[str]) -> int:
        """Karakter dizisi listesi olarak verilen bayrakları 8-bitlik tamsayıya kodlar."""
        # Girdi tipinin liste olduğunu doğrular
        if not isinstance(flag_list, list):
            # Tip uyuşmazlığında hata üretir
            raise TCPValidationError("Bayraklar liste (list) tipinde olmalıdır.")
        # Başlangıç bit maskesini sıfırlar
        mask = 0
        # Listedeki her bir bayrak adını inceler
        for f in flag_list:
            # Bayrağın metin olduğunu teyit eder
            if not isinstance(f, str):
                # Tip hatasında istisna fırlatır
                raise TCPValidationError(f"Geçersiz bayrak elemanı: {f}")
            # Bayrak adını büyük harfe dönüştürür ve temizler
            f_clean = f.strip().upper()
            # Bayrağın geçerli TCP bayrakları arasında olup olmadığını kontrol eder
            if f_clean not in cls.FLAG_MAP:
                # Tanımsız bayrakta hata verir
                raise TCPValidationError(f"Tanımsız ve geçersiz TCP bayrağı: {f}")
            # Bit düzeyinde VEYA işlemiyle maskeye ekler
            mask |= cls.FLAG_MAP[f_clean]
        # Oluşturulan 8-bitlik maskeyi döner
        return mask

    @classmethod
    def decode_flags(cls, mask: int) -> List[str]:
        """Tamsayı bit maskesini okunabilir bayrak isimleri listesine dönüştürür."""
        # Maskenin tamsayı olduğunu denetler
        if not isinstance(mask, int):
            # Geçersiz tipte hata verir
            raise TCPValidationError("Maske değeri tamsayı olmalıdır.")
        # Aktif bayrakları toplayacak boş liste
        active_flags: List[str] = []
        # Tanımlı tüm bayrakları sırayla kontrol eder
        for name, bit in cls.FLAG_MAP.items():
            # İlgili bit aktifse listeye ekler
            if mask & bit:
                # Bayrak adını ekler
                active_flags.append(name)
        # Aktif bayraklar listesini döner
        return active_flags

    @classmethod
    def audit_flag_anomalies(cls, flag_list: List[str]) -> List[str]:
        """Şüpheli veya kural dışı bayrak kombinasyonlarını (tarama/probe) denetler."""
        # Bayrak listesini normalize eder
        flags_set = {f.strip().upper() for f in flag_list if isinstance(f, str)}
        # Tespit edilen şüpheli anomalileri toplayan liste
        anomalies: List[str] = []

        # 1. NULL Scan Denetimi: Hiçbir bayrak aktif değilse
        if len(flags_set) == 0:
            # NULL tarama uyarısı ekler
            anomalies.append("NULL_SCAN_SUSPICION: Hiçbir TCP bayrağı ayarlanmamış (Port tarama probu).")

        # 2. SYN + FIN Çelişkisi: Hem bağlantı aç hem kapat aynı anda olamaz
        if "SYN" in flags_set and "FIN" in flags_set:
            # Çelişkili bayrak uyarısı ekler
            anomalies.append("ILLEGAL_FLAG_COMBINATION: SYN ve FIN aynı anda aktif (Güvenlik duvarı atlatma girişimi).")

        # 3. SYN + RST Çelişkisi: Hem senkronize et hem sıfırla
        if "SYN" in flags_set and "RST" in flags_set:
            # Çelişkili bayrak uyarısı ekler
            anomalies.append("ILLEGAL_FLAG_COMBINATION: SYN ve RST aynı anda aktif (Geçersiz durum).")

        # 4. FIN + RST Çelişkisi: Hem normal sonlandırma hem zorla sıfırlama
        if "FIN" in flags_set and "RST" in flags_set:
            # Çelişkili bayrak uyarısı ekler
            anomalies.append("ILLEGAL_FLAG_COMBINATION: FIN ve RST aynı anda aktif.")

        # 5. XMAS Scan Denetimi: FIN, PSH ve URG bayraklarının üçü birden aktifse
        if "FIN" in flags_set and "PSH" in flags_set and "URG" in flags_set:
            # XMAS tarama uyarısı ekler
            anomalies.append("XMAS_SCAN_SUSPICION: FIN+PSH+URG Noel ağacı (XMAS) tarama probu tespit edildi.")

        # Bulunan tüm anomali mesajlarını döner
        return anomalies


class TCPPacket:
    """Tekil bir TCP segmentini temsil eden ve doğruluğunu garanti eden veri modeli."""

    def __init__(
        self,
        src_port: int,
        dst_port: int,
        seq: int,
        ack: int,
        flags: List[str],
        window: int = 64240,
        payload: bytes = b"",
        src_ip: str = "127.0.0.1",
        dst_ip: str = "127.0.0.1",
        mss: int = 1460,
    ) -> None:
        # Kaynak portunun geçerliliğini denetler
        if not isinstance(src_port, int) or src_port < 0 or src_port > 65535:
            # Geçersiz port hatası fırlatır
            raise TCPValidationError(f"Kaynak portu 0-65535 aralığında olmalıdır: {src_port}")
        # Hedef portunun geçerliliğini denetler
        if not isinstance(dst_port, int) or dst_port < 0 or dst_port > 65535:
            # Geçersiz port hatası fırlatır
            raise TCPValidationError(f"Hedef portu 0-65535 aralığında olmalıdır: {dst_port}")
        # Sıra numarasının (Sequence Number) 32-bit sınırında olduğunu doğrular
        if not isinstance(seq, int) or seq < 0 or seq > 4294967295:
            # Geçersiz Sequence hatası fırlatır
            raise TCPValidationError(f"Sıra numarası (SEQ) 0-4294967295 aralığında olmalıdır: {seq}")
        # Onay numarasının (Acknowledgment Number) 32-bit sınırında olduğunu doğrular
        if not isinstance(ack, int) or ack < 0 or ack > 4294967295:
            # Geçersiz ACK hatası fırlatır
            raise TCPValidationError(f"Onay numarası (ACK) 0-4294967295 aralığında olmalıdır: {ack}")
        # Pencere boyutunun 16-bit sınırında olduğunu teyit eder
        if not isinstance(window, int) or window < 0 or window > 65535:
            # Geçersiz pencere boyutu hatası
            raise TCPValidationError(f"Pencere boyutu (Window) 0-65535 aralığında olmalıdır: {window}")
        
        # IP adreslerini basit oktet kontrolüyle denetler
        for ip_addr, label in [(src_ip, "Kaynak IP"), (dst_ip, "Hedef IP")]:
            # Dize kontrolü
            if not isinstance(ip_addr, str):
                # Hata fırlatır
                raise TCPValidationError(f"{label} metin (str) olmalıdır: {ip_addr}")
            # IPv4 parçalarını ayırır
            octets = ip_addr.split(".")
            # 4 oktet kontrolü
            if len(octets) != 4 or not all(o.isdigit() and 0 <= int(o) <= 255 for o in octets):
                # Hatalı IP formatında istisna üretir
                raise TCPValidationError(f"Geçersiz {label} adresi: {ip_addr}")

        # Bayrakları kodlayarak geçerliliğini teyit eder
        self.flag_mask: int = TCPFlags.encode_flags(flags)
        # Bayrak listesini saklar
        self.flags: List[str] = [f.upper() for f in flags]
        # Kaynak portunu saklar
        self.src_port: int = src_port
        # Hedef portunu saklar
        self.dst_port: int = dst_port
        # Sıra numarasını saklar
        self.seq: int = seq
        # Onay numarasını saklar
        self.ack: int = ack
        # Pencere boyutunu saklar
        self.window: int = window
        # Veri yükünü saklar
        self.payload: bytes = payload if isinstance(payload, bytes) else str(payload).encode("utf-8")
        # Kaynak IP adresini saklar
        self.src_ip: str = src_ip
        # Hedef IP adresini saklar
        self.dst_ip: str = dst_ip
        # Maksimum Segment Boyutunu (MSS) saklar
        self.mss: int = mss

    def has_flag(self, flag_name: str) -> bool:
        """Bu pakette belirtilen bayrağın aktif olup olmadığını sorgular."""
        # Bayrak adını büyük harfle kontrol eder
        return flag_name.upper() in self.flags


class TCPHandshakeEngine:
    """RFC 793 ve RFC 9293 uyumlu durum makinesi ve üçlü el sıkışma yöneticisi."""

    def __init__(self, secret_key: bytes = b"SiberGuvenlik365GunKey") -> None:
        # SYN Cookie üretiminde kullanılacak gizli anahtarı saklar
        self.secret_key: bytes = secret_key
        # İstemci tarafı durumunu CLOSED olarak başlatır
        self.client_state: str = "CLOSED"
        # Sunucu tarafı durumunu LISTEN olarak başlatır
        self.server_state: str = "LISTEN"
        # İstemcinin başlangıç sıra numarasını (ISN_c) saklar
        self.isn_client: Optional[int] = None
        # Sunucunun başlangıç sıra numarasını (ISN_s) saklar
        self.isn_server: Optional[int] = None
        # Bağlantı oturum günlüğünü tutar
        self.event_log: List[Dict[str, Any]] = []

    def generate_syn_cookie(self, src_ip: str, src_port: int, dst_ip: str, dst_port: int, mss_idx: int = 2) -> int:
        """Sunucunun durumsuz (stateless) SYN Cookie üretmesini sağlar (RFC 4987)."""
        # Zaman damgasını (64 saniyelik sayaç) hesaplar
        timestamp_chunk = int(time.time() // 64) & 0x1F  # 5-bit zaman
        # Bağlantı 4'lüsünü (4-tuple) ve zaman damgasını birleştirir
        cookie_data = f"{src_ip}:{src_port}:{dst_ip}:{dst_port}:{timestamp_chunk}".encode("utf-8")
        # SHA-256 HMAC ile 24-bitlik kriptografik özet üretir
        digest = hmac.new(self.secret_key, cookie_data, hashlib.sha256).digest()
        # İlk 3 baytı tamsayıya çevirir (24 bit)
        hash_val = int.from_bytes(digest[:3], byteorder="big")
        # 32-bit Cookie yapısı: [5 bit Zaman | 3 bit MSS İndeksi | 24 bit Kriptografik Hash]
        syn_cookie = (timestamp_chunk << 27) | ((mss_idx & 0x07) << 24) | (hash_val & 0xFFFFFF)
        # 32-bit tamsayı döner
        return syn_cookie

    def verify_syn_cookie(self, ack_val: int, src_ip: str, src_port: int, dst_ip: str, dst_port: int) -> bool:
        """İstemciden dönen ACK paketindeki onay numarasının meşru bir SYN Cookie olup olmadığını doğrular."""
        # İstemcinin ACK numarası Sunucu SEQ + 1 olduğu için 1 çıkararak orijinal cookie bulunur
        original_cookie = (ack_val - 1) & 0xFFFFFFFF
        # Cookie içinden zaman damgasını çıkarır (en üst 5 bit)
        ts_chunk = (original_cookie >> 27) & 0x1F
        # Cookie içinden 24 bitlik hash değerini çıkarır
        cookie_hash = original_cookie & 0xFFFFFF
        
        # Güncel zaman dilimini hesaplar
        current_chunk = int(time.time() // 64) & 0x1F
        # Zaman aşımı toleransı (en fazla 1 dilim fark kabul edilir)
        if (current_chunk - ts_chunk) % 32 > 2:
            # Süresi dolmuş cookie reddedilir
            return False

        # Beklenen hash değerini yeniden üretir
        cookie_data = f"{src_ip}:{src_port}:{dst_ip}:{dst_port}:{ts_chunk}".encode("utf-8")
        # HMAC özetini hesaplar
        digest = hmac.new(self.secret_key, cookie_data, hashlib.sha256).digest()
        # 24-bit değeri alır
        expected_hash = int.from_bytes(digest[:3], byteorder="big") & 0xFFFFFF
        # Hash eşleşmesini doğrular
        return cookie_hash == expected_hash

    def process_step_1_client_syn(self, packet: TCPPacket) -> Dict[str, Any]:
        """1. ADIM: İstemciden Sunucuya SYN Gönderimi (Bağlantı Talebi)."""
        # Paketin sadece SYN bayrağı taşıdığını kontrol eder
        if not packet.has_flag("SYN") or packet.has_flag("ACK"):
            # Geçersiz başlangıç paketinde hata verir
            raise TCPValidationError("El sıkışmanın 1. adımı yalnızca SYN bayrağı taşımalıdır (ACK kapalı olmalıdır).")
        # Onay numarasının sıfır olduğunu teyit eder (İlk bağlantıda onaylanacak bir şey yoktur)
        if packet.ack != 0:
            # Sıfır dışı ACK'de kural ihlali
            raise TCPValidationError(f"İlk SYN paketinde ACK alanı 0 olmalıdır, gelen: {packet.ack}")

        # İstemcinin ISN değerini kaydeder
        self.isn_client = packet.seq
        # İstemci durumu SYN_SENT olur
        self.client_state = "SYN_SENT"
        # Olay kaydı oluşturur
        log_entry = {
            "adim": 1,
            "eylem": "CLIENT_SYN_SENT",
            "istemci_durum": self.client_state,
            "sunucu_durum": self.server_state,
            "seq": packet.seq,
            "ack": packet.ack,
            "mesaj": f"İstemci bağlantı isteği başlattı (ISN_c={packet.seq})."
        }
        # Günlüğe ekler
        self.event_log.append(log_entry)
        # Olay bilgisini döner
        return log_entry

    def process_step_2_server_syn_ack(self, packet: TCPPacket) -> Dict[str, Any]:
        """2. ADIM: Sunucudan İstemciye SYN-ACK Yanıtı (Kabul ve Karşı İstek)."""
        # İstemcinin daha önce SYN göndermiş olduğunu teyit eder
        if self.client_state != "SYN_SENT" or self.isn_client is None:
            # Sıra dışı işlemde hata fırlatır
            raise TCPValidationError("SYN gönderilmeden SYN-ACK kabul edilemez (Sıra dışı durum).")
        # Paketin hem SYN hem ACK taşıdığını kontrol eder
        if not (packet.has_flag("SYN") and packet.has_flag("ACK")):
            # Eksik bayrakta hata verir
            raise TCPValidationError("El sıkışmanın 2. adımı hem SYN hem ACK bayrağı taşımalıdır.")
        
        # Sunucunun gönderdiği ACK değerinin (ISN_c + 1) olduğunu matematiksel olarak doğrular
        expected_ack = (self.isn_client + 1) & 0xFFFFFFFF
        # Beklenen ACK ile gelen ACK eşleşiyor mu
        if packet.ack != expected_ack:
            # Uyuşmazlıkta hata fırlatır
            raise TCPValidationError(f"Geçersiz ACK numarası! Beklenen: {expected_ack}, Gelen: {packet.ack}")

        # Sunucunun ISN değerini kaydeder
        self.isn_server = packet.seq
        # Sunucu durumu SYN_RECEIVED olur
        self.server_state = "SYN_RECEIVED"
        # Olay kaydı oluşturur
        log_entry = {
            "adim": 2,
            "eylem": "SERVER_SYN_ACK_SENT",
            "istemci_durum": self.client_state,
            "sunucu_durum": self.server_state,
            "seq": packet.seq,
            "ack": packet.ack,
            "mesaj": f"Sunucu bağlantıyı kabul etti (ISN_s={packet.seq}, ACK={packet.ack})."
        }
        # Günlüğe ekler
        self.event_log.append(log_entry)
        # Olay bilgisini döner
        return log_entry

    def process_step_3_client_ack(self, packet: TCPPacket) -> Dict[str, Any]:
        """3. ADIM: İstemciden Sunucuya Son ACK Gönderimi (Bağlantı Kuruldu / ESTABLISHED)."""
        # Önceki aşamaların tamamlandığını doğrular
        if self.server_state != "SYN_RECEIVED" or self.isn_server is None or self.isn_client is None:
            # Beklenmeyen durumda hata fırlatır
            raise TCPValidationError("Sunucu SYN_RECEIVED durumunda değilken son ACK işlenemez.")
        # Paketin sadece ACK taşıdığını kontrol eder (SYN kapalı olmalıdır)
        if not packet.has_flag("ACK") or packet.has_flag("SYN"):
            # Kural ihlalinde hata fırlatır
            raise TCPValidationError("El sıkışmanın 3. adımı yalnızca ACK bayrağı taşımalıdır (SYN kapalı olmalıdır).")

        # İstemcinin SEQ numarasının (ISN_c + 1) olduğunu doğrular
        expected_seq = (self.isn_client + 1) & 0xFFFFFFFF
        # İstemcinin ACK numarasının (ISN_s + 1) olduğunu doğrular
        expected_ack = (self.isn_server + 1) & 0xFFFFFFFF

        # Sıra numarası uyuşmazlığı kontrolü
        if packet.seq != expected_seq:
            # SEQ hatası
            raise TCPValidationError(f"Hatalı İstemci SEQ! Beklenen: {expected_seq}, Gelen: {packet.seq}")
        # Onay numarası uyuşmazlığı kontrolü
        if packet.ack != expected_ack:
            # ACK hatası
            raise TCPValidationError(f"Hatalı İstemci ACK! Beklenen: {expected_ack}, Gelen: {packet.ack}")

        # Her iki tarafın durumu da ESTABLISHED (Kuruldu) seviyesine geçer
        self.client_state = "ESTABLISHED"
        # Sunucu da kurulu seviyesine geçer
        self.server_state = "ESTABLISHED"
        
        # Olay kaydı oluşturur
        log_entry = {
            "adim": 3,
            "eylem": "CONNECTION_ESTABLISHED",
            "istemci_durum": self.client_state,
            "sunucu_durum": self.server_state,
            "seq": packet.seq,
            "ack": packet.ack,
            "mesaj": "Üçlü el sıkışma başarıyla tamamlandı. Oturum kuruldu (ESTABLISHED)."
        }
        # Günlüğe ekler
        self.event_log.append(log_entry)
        # Olay bilgisini döner
        return log_entry


class TCPSecurityAuditor:
    """TCP Güvenlik Tehditleri (SYN Flood, ISN Tahmini, Kural Dışı Bayraklar) Denetleyicisi."""

    def __init__(self, backlog_limit: int = 128) -> None:
        # Sunucunun yarım açık bağlantı (half-open) kuyruk sınırı
        self.backlog_limit: int = backlog_limit
        # Mevcut yarım açık bağlantıları tutan sözlük
        self.half_open_connections: Dict[str, float] = {}
        # Tespit edilen güvenlik alarmları listesi
        self.security_alerts: List[Dict[str, Any]] = []

    def record_syn_request(self, client_ip: str, client_port: int) -> Optional[Dict[str, Any]]:
        """Gelen bir SYN isteğini yarım açık kuyruğa ekler ve kuyruk taşmasını (SYN Flood) denetler."""
        # Bağlantı kimliğini oluşturur
        conn_key = f"{client_ip}:{client_port}"
        # İsteği zaman damgasıyla kaydeder
        self.half_open_connections[conn_key] = time.time()
        
        # Kuyruk derinliğini kontrol eder
        current_depth = len(self.half_open_connections)
        # Kuyruk limiti aşıldığında alarm üretir
        if current_depth > self.backlog_limit:
            # SYN Flood alarm nesnesi
            alert = {
                "kategori": "SYN_FLOOD_SALDIRISI",
                "seviye": "KRITIK",
                "kaynak": client_ip,
                "kuyruk_derinligi": current_depth,
                "limit": self.backlog_limit,
                "mesaj": f"Yarım açık bağlantı kuyruğu limiti ({self.backlog_limit}) aşıldı! SYN Flood DoS şüphesi."
            }
            # Listeye ekler
            self.security_alerts.append(alert)
            # Alarmı döner
            return alert
        # Limit aşılmadıysa None döner
        return None

    def release_connection(self, client_ip: str, client_port: int) -> None:
        """Son ACK geldiğinde veya bağlantı kapandığında kuyruktan düşer."""
        # Bağlantı anahtarını oluşturur
        conn_key = f"{client_ip}:{client_port}"
        # Sözlükte varsa siler
        if conn_key in self.half_open_connections:
            # Kuyruktan kaldırır
            del self.half_open_connections[conn_key]

    @staticmethod
    def audit_isn_predictability(isn_list: List[int]) -> Optional[Dict[str, Any]]:
        """Sunucu tarafından üretilen ISN değerlerinin tahmin edilebilirliğini (entropi) denetler."""
        # Yeterli örnek yoksa analiz yapılamaz
        if len(isn_list) < 3:
            # Yetersiz veride None döner
            return None
        
        # Ardışık ISN farklarını hesaplar
        diffs = [isn_list[i+1] - isn_list[i] for i in range(len(isn_list)-1)]
        # Tüm farklar sabit mi (lineer artış)
        if len(set(diffs)) == 1:
            # Sabit fark durumu: Tahmin edilebilir ISN zafiyeti
            return {
                "kategori": "TAHMIN_EDILEBILIR_ISN_ZAFİYETI",
                "seviye": "YUKSEK",
                "sabit_artis": diffs[0],
                "ornekler": isn_list[:5],
                "mesaj": f"ISN değerleri sabit bir artış ({diffs[0]}) ile üretiliyor! TCP Sequence Prediction ve Spoofing riski."
            }
        # Tahmin edilemez/güvenli durumda None döner
        return None


def run_comprehensive_handshake_analysis(json_path: str) -> str:
    """Verilen JSON dosyasını okuyarak tam el sıkışma ve güvenlik analizini yürütür."""
    # Dosyanın varlığını denetler
    if not os.path.exists(json_path):
        # Dosya yoksa hata verir
        raise TCPValidationError(f"Örnek dosya bulunamadı: {json_path}")
    
    # JSON dosyasını açar
    with open(json_path, "r", encoding="utf-8") as f:
        # Veriyi okur
        data = json.load(f)

    # Rapor satırlarını toplar
    lines: List[str] = []
    # Rapor başlığı
    lines.append("# 🌐 TCP Üçlü El Sıkışma (3-Way Handshake) ve Güvenlik Denetim Raporu\n")
    # Lisans bildirimi
    lines.append("**ÖZEL LİSANS — TÜM HAKLAR SAKLIDIR**  ")
    # Telif hakkı
    lines.append("*Telif Hakkı (c) 2026 Seydi Eryılmaz (@seydivakkas)*\n")
    # Ayırıcı çizgi
    lines.append("---\n")

    # Güvenlik denetleyicisi nesnesi (Test için backlog limiti düşük tutulur: 3)
    auditor = TCPSecurityAuditor(backlog_limit=3)

    # Tüm oturumları döngüyle inceler
    for sess in data.get("oturumlar", []):
        # Oturum ID'si ve başlığı
        sess_id = sess.get("oturum_id", "BILINMEYEN")
        # Açıklama
        desc = sess.get("aciklama", "")
        # Bölüm başlığı ekler
        lines.append(f"## Oturum: {sess_id} — {desc}\n")

        # 1. Normal Handshake Oturumu ise
        if "paketler" in sess:
            # El sıkışma motorunu başlatır
            engine = TCPHandshakeEngine()
            # Paket tablosu başlığı
            lines.append("| Adım | Yön | Bayraklar | SEQ | ACK | Pencere | Açıklama |")
            # Tablo ayırıcı
            lines.append("|---|---|---|---|---|---|---|")
            
            # Paketleri sırayla işler
            for p_data in sess["paketler"]:
                # Paket nesnesini oluşturur
                pkt = TCPPacket(
                    src_port=sess.get("istemci_port", 12345),
                    dst_port=sess.get("sunucu_port", 80),
                    seq=p_data["seq"],
                    ack=p_data["ack"],
                    flags=p_data["bayraklar"],
                    window=p_data.get("pencere", 64240),
                    mss=p_data.get("mss", 1460)
                )
                # Adıma göre durum makinesini işletir
                if p_data["adim"] == 1:
                    # 1. Adım SYN
                    engine.process_step_1_client_syn(pkt)
                elif p_data["adim"] == 2:
                    # 2. Adım SYN-ACK
                    engine.process_step_2_server_syn_ack(pkt)
                elif p_data["adim"] == 3:
                    # 3. Adım ACK
                    engine.process_step_3_client_ack(pkt)

                # Tablo satırını oluşturur
                satir = (
                    f"| {p_data['adim']} | `{p_data['yon']}` | `{','.join(p_data['bayraklar'])}` | "
                    f"`{p_data['seq']}` | `{p_data['ack']}` | `{p_data.get('pencere', '-')}` | "
                    f"{p_data['aciklama']} |"
                )
                # Satırı rapora ekler
                lines.append(satir)
            
            # Oturum sonucunu ekler
            lines.append(f"\n✅ **Oturum Durumu:** İstemci: `{engine.client_state}`, Sunucu: `{engine.server_state}`\n")

        # 2. SYN Flood Simülasyonu ise
        elif "sahte_syn_istekleri" in sess:
            # Açıklama metni
            lines.append("### SYN Flood Saldırı Simülasyonu Bulguları\n")
            # Her bir sahte SYN isteğini kaydeder
            for req in sess["sahte_syn_istekleri"]:
                # SYN isteğini denetleyiciye iletir
                alert = auditor.record_syn_request(req["kaynak_ip"], req["kaynak_port"])
                # Alarm varsa ekrana ve rapora basar
                if alert:
                    # Alarm satırını ekler
                    lines.append(f"- 🚨 **{alert['seviye']}**: `{alert['kategori']}` — {alert['mesaj']} (Kaynak: `{alert['kaynak']}`)")
            # Boşluk bırakır
            lines.append("")

        # 3. Şüpheli Bayrak Kombinasyonları ise
        elif "supheli_paketler" in sess:
            # Açıklama metni
            lines.append("### Kural Dışı ve Şüpheli Bayrak Analizi (Port Scan / Probing)\n")
            # Tablo başlığı
            lines.append("| Test ID | Bayraklar | Hedef Port | Tespit Edilen Güvenlik Anomalisi |")
            # Tablo ayırıcı
            lines.append("|---|---|---|---|")
            # Paketleri inceler
            for probe in sess["supheli_paketler"]:
                # Bayrak anomalilerini denetler
                anomalies = TCPFlags.audit_flag_anomalies(probe["bayraklar"])
                # Anomali metni
                anom_text = "<br>".join(anomalies) if anomalies else "Normal"
                # Bayrak metni
                flags_text = ",".join(probe["bayraklar"]) if probe["bayraklar"] else "YOK (NULL)"
                # Satırı oluşturur
                satir = f"| `{probe['test_id']}` | `{flags_text}` | `{probe['hedef_port']}` | {anom_text} |"
                # Rapora ekler
                lines.append(satir)
            # Boşluk
            lines.append("")

        # 4. Predictable ISN Analizi ise
        elif "ornek_isn_dizisi" in sess:
            # Açıklama metni
            lines.append("### Başlangıç Sıra Numarası (ISN) Entropi Denetimi\n")
            # ISN dizisini analiz eder
            isn_alert = TCPSecurityAuditor.audit_isn_predictability(sess["ornek_isn_dizisi"])
            # Zafiyet bulunduysa
            if isn_alert:
                # Zafiyet bilgisini rapora ekler
                lines.append(f"- ⚠️ **{isn_alert['seviye']}**: `{isn_alert['kategori']}` — {isn_alert['mesaj']}\n")

    # 4. BÖLÜM: Savunma İlkeleri
    lines.append("## Savunma ve Sıkılaştırma Önerileri\n")
    # 1. Kural
    lines.append("1. **SYN Cookies (RFC 4987):** SYN Flood saldırılarına karşı çekirdekte `net.ipv4.tcp_syncookies = 1` aktif edilmeli, bellek tüketimi önlenmelidir.")
    # 2. Kural
    lines.append("2. **Kriptografik ISN Üretimi (RFC 6528):** Sıra numaraları rastgele ve tahmin edilemez kriptografik PRNG motorları ile oluşturulmalıdır.")
    # 3. Kural
    lines.append("3. **Stateful Firewall & TCP Normalization:** Geçersiz bayrak kombinasyonları (SYN+FIN, NULL, XMAS) sınır güvenlik duvarında anında düşürülmelidir.\n")

    # Tam metni döner
    return "\n".join(lines)


if __name__ == "__main__":
    # Konsol standart çıktısını UTF-8 olarak yeniden yapılandırmak için sys modülü
    import sys
    # Windows konsolunda Unicode ve emoji karakterlerinin güvenle yazılabilmesi için UTF-8 ayarı
    if hasattr(sys.stdout, "reconfigure"):
        # Standart çıktıyı UTF-8 kodlamasına geçirir
        sys.stdout.reconfigure(encoding="utf-8")
    # Konsol bilgi mesajı
    print("================================================================================")
    # Başlık
    print("[+] Gün 050: TCP Üçlü El Sıkışma Analizörü ve Güvenlik Denetim Motoru")
    # Çizgi
    print("================================================================================")
    
    # Örnek veri yolu
    sample_file = os.path.join(os.path.dirname(__file__), "..", "ornek_veri", "sample_tcp_handshakes.json")
    # Mutlak yola çevirir
    sample_file = os.path.abspath(sample_file)
    
    # Analizi çalıştırır
    rapor_metni = run_comprehensive_handshake_analysis(sample_file)
    # Konsola yazdırır
    print(rapor_metni)
    
    # Rapor dosyasını kaydeder
    rapor_cikis_yolu = os.path.join(os.path.dirname(__file__), "..", "kanit", "gercek", "tcp_el_sikisma_raporu.txt")
    # Mutlak yola çevirir
    rapor_cikis_yolu = os.path.abspath(rapor_cikis_yolu)
    # Dizin oluşturur
    os.makedirs(os.path.dirname(rapor_cikis_yolu), exist_ok=True)
    # Dosyaya yazar
    with open(rapor_cikis_yolu, "w", encoding="utf-8") as f:
        # İçeriği yazar
        f.write(rapor_metni)
    # Bilgi mesajı
    print(f"\n[+] TCP Analiz Raporu Başarıyla Kaydedildi: {rapor_cikis_yolu}")
    print("================================================================================")
