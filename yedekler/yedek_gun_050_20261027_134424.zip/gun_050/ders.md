# Gün 050: TCP Üçlü El Sıkışma (3-Way Handshake) ve Bağlantı Güvenliği

**ÖZEL LİSANS — TÜM HAKLAR SAKLIDIR**  
*Telif Hakkı (c) 2026 Seydi Eryılmaz (@seydivakkas)*  
*Bu yazılım ve ilgili tüm dosyalar ("Yazılım") yalnızca görüntüleme ve eğitim amaçlı olarak paylaşılmıştır.*

---

## 1. Ustanın Girişi: Katman-4'e Hoş Geldin, Evlat!

Geçtiğimiz hafta seninle Katman-2 (Ethernet, MAC, ARP) ve Katman-3 (IPv4, IPv6, ICMP) diyarlarında fırtınalar kopardık. Ancak unutmaman gereken çok hayati bir hakikat var: **IP protokolü güvenilmezdir (unreliable) ve bağlantısızdır (connectionless).** 

IP katmanı paketleri hedefe ulaştırmak için elinden gelenin en iyisini yapar (best-effort delivery); ancak paket yolda düşerse, sırası bozulursa ya da kopyalanırsa IP'nin kılı bile kıpırdamaz, haberi dahi olmaz! 

İşte internetin çökmek yerine tıkır tıkır çalışmasını sağlayan gizli kahraman **Katman-4 Taşıma Katmanı (Transport Layer)** ve onun en güvenilir işçisi olan **TCP (Transmission Control Protocol - RFC 793 / RFC 9293)** protokolüdür.

Bugün konumuz: İki cihazın birbirine veri aktarmadan önce yaptığı o kutsal protokol ritüeli, yani **TCP Üçlü El Sıkışma (3-Way Handshake)**. Bu mekanizmayı sadece bir bağlantı kurucu olarak görürsen çırak kalırsın. Bir siber güvenlik ustası olarak sen; bu üç adımın arka planında dönen sıra numarası entropisini, yarım açık bağlantı kuyruklarını (backlog queue), SYN Flood hizmet dışı bırakma (DoS) saldırılarını ve kural dışı bayraklarla yapılan gizli port taramalarını (XMAS, NULL) ciğerine kadar bileceksin.

---

## 2. Neden İki Değil de Üç Adım? (Handshake Anatomisi)

Çırakların en sık sorduğu soru şudur: *"Hocam, ben istemci olarak bağlanmak istediğimi söylesem (SYN), sunucu da tamam bağlandın dese (ACK), iki adımda bu iş bitmez mi? Neden üçüncü bir ACK paketiyle uğraşıyoruz?"*

Dinle evlat: Ağ ortamı çift yönlüdür (full-duplex) ve paketler gecikebilir, kopyalanabilir.
1. **1. Adım (SYN - İstemciden Sunucuya):** İstemci sunucuya der ki: *"Ben seninle bir oturum kurmak istiyorum. Benim bayt sayacımın başlangıç noktası (Initial Sequence Number - ISN_c) örneğin 1000'dir. Beni bu sayaçtan takip et."*
2. **2. Adım (SYN-ACK - Sunucudan İstemciye):** Sunucu istemcinin isteğini onaylar: *"Mesajını aldım, senin 1000 nolu sıra numaranı duydum, senden bir sonraki beklediğim bayt 1001'dir (ACK=1001). Peki sen beni duyabiliyor musun? Benim de kendi başlangıç sayacım var (ISN_s), o da örneğin 5000'dir (SYN=5000)."*
3. **3. Adım (ACK - İstemciden Sunucuya):** Eğer bu adım olmasaydı, sunucu istemcinin kendi SYN-ACK yanıtını aldığından asla emin olamazdı! Eski, ağda dolanıp gecikmiş hayalet bir SYN paketi sunucuya ulaştığında sunucu oturum açar ve boş yere kaynak tüketirdi. İstemci son ACK ile der ki: *"Senin 5000 nolu sayacını da duydum, senden beklediğim sonraki bayt 5001'dir (ACK=5001). Artık her iki yön de eşitlendi, sözleşme tamamlandı (ESTABLISHED)!"*

Unutma: **Her TCP paketi uygulama verisi taşımaz!** Bu ilk üç paketin payload'ı (veri yükü) kural olarak sıfır bayttır. Ancak SYN ve FIN bayrakları, sıra numarası uzayında sanal olarak 1 bayt tüketir. Bu yüzden ACK numarası her zaman `ISN + 1` olarak döner.

---

## 3. TCP Başlık Bayrakları (Flags) ve Kural Dışı Problar

TCP başlığında bağlantının kontrolünü sağlayan kritik bayraklar (flags) bulunur:
- **SYN (Synchronize):** Bağlantı kurulumu.
- **ACK (Acknowledgment):** Onay alanının geçerli olduğunu gösterir.
- **FIN (Finish):** İki taraflı zarif bağlantı sonlandırma.
- **RST (Reset):** Bağlantıyı anında ve zorla koparma (Port kapalıysa veya anomali varsa döner).
- **PSH (Push):** Tamponu beklemeden veriyi işletim sistemine/uygulamaya fırlat.
- **URG (Urgent):** Acil veri işaretçisi.

### Saldırganların Kurnazlığı: Kural Dışı Bayrak Kombinasyonları
Normal bir yazılım asla kurallara aykırı bayrak gönderemez. Ancak `nmap` gibi port tarayıcıları ve siber saldırganlar, hedef sistemlerin işletim sistemi TCP/IP yığınını (fingerprint) tespit etmek veya durum bilgisi tutmayan eski güvenlik duvarlarını atlatmak için kural dışı paketler üretir:
1. **NULL Scan (0 Bayrak):** Hiçbir bayrak işaretlenmemiştir. RFC 793'e göre kapalı bir port RST dönmeli, açık port ise paketi sessizce düşürmelidir.
2. **XMAS Scan (FIN + PSH + URG):** Paketin tüm ışıkları bir Noel ağacı gibi yanar! Kapalı portlar RST dönerken açık portlar sessiz kalır.
3. **SYN + FIN Çelişkisi:** Aynı anda hem kapıyı açmak hem kapıyı çarparak kapatmak demektir. Protokol kurallarına aykırıdır; güvenlik duvarlarının durum tablosunu karıştırmak için kullanılır.

---

## 4. En Büyük Kâbus: SYN Flood Saldırısı ve TCB Tüketimi

Sunucu 1. adımda bir SYN paketi aldığında, henüz 3. adım tamamlanmadığı için bağlantıyı **Yarım Açık (Half-Open)** durumuna alır. İşletim sistemi çekirdeği bu bağlantı için bellekte bir **TCB (Transmission Control Block)** yapısı ayırır ve bunu **SYN Backlog Kuyruğu**na koyar.

Saldırgan binlerce sahte (spoofed) IP adresinden sürekli SYN paketi yollar; ancak gelen SYN-ACK'lara **asla son ACK paketini dönmez!**
- Sunucunun backlog kuyruğu saniyeler içinde dolar (örneğin 128 veya 1024 sınırına ulaşır).
- Kuyruk dolduğu an, sunucu meşru kullanıcılardan gelen gerçek SYN isteklerini reddetmeye başlar.
- Sunucu ayaktadır, CPU ve bant genişliği boştadır; fakat tek bir yeni kullanıcı bile web sitesine bağlanamaz! İşte buna **SYN Flood Hizmet Dışı Bırakma (DoS) Saldırısı** denir.

---

## 5. Ustanın Savunma Kalkanı: SYN Cookies (RFC 4987)

Sunucuyu bu felaketten nasıl kurtaracağız? Cevap: **SYN Cookies**.

SYN Cookie devredeyken sunucu, gelen SYN paketi için bellekte **HİÇBİR ŞEY KAYDETMEZ (Stateless)**:
1. Sunucu, istemcinin IP'sini, portunu, kendi IP'sini, portunu ve gizli bir anahtarı alarak kriptografik bir hash (HMAC) üretir.
2. Bu hash değerini, zaman damgası ve MSS bilgisiyle birleştirip kendi başlangıç sıra numarası (`ISN_s`) yapar:
   $$\text{ISN}_s = \text{Cookie} = \text{Zaman} \ | \ \text{MSS İndeksi} \ | \ \text{HMAC}(\text{4-Tuple}, \text{Secret})$$
3. Bu cookie'yi SYN-ACK içinde istemciye gönderir ve bağlantıyı unutur! Bellek harcanmaz.
4. Eğer karşımızdaki gerçek bir istemciyse, 3. adımda `ACK = Cookie + 1` ile geri gelecektir. Sunucu gelen ACK'tan 1 çıkarır, kendi kriptografik formülüyle doğrular. Eğer matematik tutuyorsa, işte o an TCB belleği tahsis edilir ve oturum `ESTABLISHED` durumuna geçirilir!

Saldırgan sahte IP kullandığı için son ACK'ı asla gönderemez; böylece sunucunun belleği zerre kadar tükenmez!

---

## 6. Sıra Numarası Tahmini (ISN Prediction & Hijacking)

Eğer bir sunucu başlangıç sıra numaralarını (ISN) rastgele üretmek yerine basitçe `1000, 2000, 3000...` gibi tahmin edilebilir şekilde artırıyorsa; saldırgan sunucunun paketlerini görmesine gerek kalmadan (blind spoofing) meşru bir istemci adına sunucuya komut enjekte edebilir (Kevin Mitnick'in 1994 yılındaki ünlü Tsutomu Shimomura saldırısı!). Günümüz modern işletim sistemleri RFC 6528 standardı gereğince kriptografik PRNG motorları kullanarak tahmin edilemez ISN üretmek zorundadır.

---

## 7. Ustanın Öğüdü

Evlat, TCP el sıkışması ağın kalbidir. Bu mekanizmanın matematiğini, zaman aşımı sürelerini ve bayrak kurallarını bilmeyen biri siber güvenlikte asla derinleşemez. 

Bugün yazdığın `TCPHandshakeEngine` ve `TCPSecurityAuditor` kodlarını iyi sakla. Bu kodlar sadece testten geçmek için değil; yarın bir gün büyük bir DDoS saldırısı altında kalan bir altyapıyı ayakta tutarken zihninde parlayacak olan fenerindir!
