# ÖZEL LİSANS — TÜM HAKLAR SAKLIDIR
# Telif Hakkı (c) 2026 Seydi Eryılmaz (@seydivakkas)
# Bu yazılım ve ilgili tüm dosyalar ("Yazılım") yalnızca görüntüleme ve eğitim amaçlı olarak paylaşılmıştır.

"""
G050: TCP Üçlü El Sıkışma (3-Way Handshake) ve Güvenlik Denetim Birim Testleri.
Bu test paketi, RFC 793/9293 el sıkışma aşamalarını, durum makinesi geçişlerini,
kural dışı bayrak taramalarını (XMAS/NULL), SYN Flood kuyruk taşmasını,
kriptografik SYN Cookie doğrulamasını ve ISN entropi analizini doğrular.
"""

# Birim testi doğrulamaları ve assertion iddiaları için pytest kütüphanesi
import pytest
# Dosya ve dizin yolu çözümleme modülü
import os
# Modül import yollarını yönetmek için sys modülü
import sys
# JSON veri okuma ve ayrıştırma modülü
import json

# Test dosyasının bulunduğu mutlak dizini alır
current_dir = os.path.dirname(os.path.abspath(__file__))
# Uygulama kaynak kod dizini yolunu oluşturur
app_dir = os.path.join(os.path.dirname(current_dir), "uygulama")
# Uygulama dizini henüz Python yolunda kayıtlı değilse listeye ekler
if app_dir not in sys.path:
    # İlk sıraya ekleyerek doğrudan import edilmesini sağlar
    sys.path.insert(0, app_dir)

# Test edilecek TCP sınıflarını ve fonksiyonlarını içe aktarır
from tcp_handshake_analyzer import (
    # Özel TCP doğrulama istisna sınıfı
    TCPValidationError,
    # TCP bayrakları ve anomali tarayıcısı
    TCPFlags,
    # TCP segment veri modeli
    TCPPacket,
    # Üçlü el sıkışma durum makinesi motoru
    TCPHandshakeEngine,
    # TCP güvenlik tehditleri ve SYN Flood denetleyicisi
    TCPSecurityAuditor,
    # Kapsamlı analiz ve rapor üretici fonksiyonu
    run_comprehensive_handshake_analysis,
)


def test_tcp_flags_encode_decode():
    """TCP bayraklarının 8-bitlik tamsayıya kodlanmasını ve geri çözülmesini test eder."""
    # Test bayrak listesi (SYN ve ACK)
    flag_list = ["SYN", "ACK"]
    # 8-bit maskeye dönüştürülür
    mask = TCPFlags.encode_flags(flag_list)
    # SYN (0x02) | ACK (0x10) = 0x12 (18) olmalıdır
    assert mask == 0x12
    # Maskeden bayrak isimleri geri çözülür
    decoded = TCPFlags.decode_flags(mask)
    # SYN çözülen listede bulunmalıdır
    assert "SYN" in decoded
    # ACK çözülen listede bulunmalıdır
    assert "ACK" in decoded


def test_tcp_flags_illegal_combinations():
    """SYN+FIN, NULL ve XMAS gibi şüpheli bayrak kombinasyonlarının tespitini test eder."""
    # 1. SYN + FIN çelişkili kombinasyonu
    anom_syn_fin = TCPFlags.audit_flag_anomalies(["SYN", "FIN"])
    # En az bir anomali tespit edilmiş olmalıdır
    assert len(anom_syn_fin) > 0
    # ILLEGAL_FLAG_COMBINATION uyarısı içermelidir
    assert "ILLEGAL_FLAG_COMBINATION" in anom_syn_fin[0]

    # 2. NULL Scan (Hiçbir bayrak yok)
    anom_null = TCPFlags.audit_flag_anomalies([])
    # NULL tarama tespiti yapılmalıdır
    assert any("NULL_SCAN_SUSPICION" in a for a in anom_null)

    # 3. XMAS Scan (FIN + PSH + URG)
    anom_xmas = TCPFlags.audit_flag_anomalies(["FIN", "PSH", "URG"])
    # XMAS tarama tespiti yapılmalıdır
    assert any("XMAS_SCAN_SUSPICION" in a for a in anom_xmas)


def test_tcp_packet_valid_creation():
    """Geçerli bir TCPPacket nesnesinin alanlarının doğru atandığını test eder."""
    # Standart bir SYN paketi oluşturulur
    pkt = TCPPacket(
        src_port=54321,
        dst_port=443,
        seq=1000,
        ack=0,
        flags=["SYN"],
        window=64240,
        src_ip="192.168.1.50",
        dst_ip="10.10.10.80"
    )
    # Kaynak portu doğrulanır
    assert pkt.src_port == 54321
    # Hedef portu doğrulanır
    assert pkt.dst_port == 443
    # SEQ numarası doğrulanır
    assert pkt.seq == 1000
    # ACK numarası doğrulanır
    assert pkt.ack == 0
    # SYN bayrağının aktif olduğu doğrulanır
    assert pkt.has_flag("SYN") is True
    # ACK bayrağının kapalı olduğu doğrulanır
    assert pkt.has_flag("ACK") is False


def test_handshake_full_legitimate_flow():
    """Standart ve meşru üçlü el sıkışmanın (SYN -> SYN-ACK -> ACK) durum geçişlerini test eder."""
    # El sıkışma motoru başlatılır
    engine = TCPHandshakeEngine()
    # Başlangıçta istemci CLOSED, sunucu LISTEN durumundadır
    assert engine.client_state == "CLOSED"
    # Sunucu LISTEN durumundadır
    assert engine.server_state == "LISTEN"

    # 1. ADIM: İstemci SYN gönderir (ISN_c = 1000)
    pkt_syn = TCPPacket(src_port=1234, dst_port=80, seq=1000, ack=0, flags=["SYN"])
    # 1. adım işletilir
    log_1 = engine.process_step_1_client_syn(pkt_syn)
    # İstemci durumu SYN_SENT olmalıdır
    assert engine.client_state == "SYN_SENT"
    # Kaydedilen istemci ISN'i 1000 olmalıdır
    assert engine.isn_client == 1000

    # 2. ADIM: Sunucu SYN-ACK döner (ISN_s = 5000, ACK = 1000 + 1 = 1001)
    pkt_syn_ack = TCPPacket(src_port=80, dst_port=1234, seq=5000, ack=1001, flags=["SYN", "ACK"])
    # 2. adım işletilir
    log_2 = engine.process_step_2_server_syn_ack(pkt_syn_ack)
    # Sunucu durumu SYN_RECEIVED olmalıdır
    assert engine.server_state == "SYN_RECEIVED"
    # Kaydedilen sunucu ISN'i 5000 olmalıdır
    assert engine.isn_server == 5000

    # 3. ADIM: İstemci ACK döner (SEQ = 1001, ACK = 5000 + 1 = 5001)
    pkt_ack = TCPPacket(src_port=1234, dst_port=80, seq=1001, ack=5001, flags=["ACK"])
    # 3. adım işletilir
    log_3 = engine.process_step_3_client_ack(pkt_ack)
    # İstemci durumu ESTABLISHED olmalıdır
    assert engine.client_state == "ESTABLISHED"
    # Sunucu durumu ESTABLISHED olmalıdır
    assert engine.server_state == "ESTABLISHED"


def test_handshake_step1_syn_with_ack_rejected():
    """El sıkışmanın ilk adımında ACK bayrağı veya sıfır dışı ACK içeren paketin reddedildiğini test eder."""
    # Motor oluşturulur
    engine = TCPHandshakeEngine()
    # Kural dışı paket: SYN+ACK ile bağlantı başlatmaya çalışır
    bad_pkt = TCPPacket(src_port=1234, dst_port=80, seq=1000, ack=500, flags=["SYN", "ACK"])
    # TCPValidationError fırlatılmalıdır
    with pytest.raises(TCPValidationError):
        # 1. adım işletildiğinde hata vermelidir
        engine.process_step_1_client_syn(bad_pkt)


def test_handshake_step2_without_step1_rejected():
    """1. adım (SYN) işletilmeden doğrudan 2. adımın (SYN-ACK) çağrılmasının engellendiğini test eder."""
    # Motor oluşturulur
    engine = TCPHandshakeEngine()
    # Rastgele bir SYN-ACK paketi oluşturulur
    pkt = TCPPacket(src_port=80, dst_port=1234, seq=5000, ack=1001, flags=["SYN", "ACK"])
    # 1. adım atlandığı için hata fırlatmalıdır
    with pytest.raises(TCPValidationError):
        # 2. adım çağrılır
        engine.process_step_2_server_syn_ack(pkt)


def test_handshake_step2_invalid_ack_number_rejected():
    """Sunucunun döndüğü ACK numarası (ISN_c + 1) ile eşleşmediğinde reddedildiğini test eder."""
    # Motor oluşturulur
    engine = TCPHandshakeEngine()
    # 1. Adım: İstemci ISN = 1000 gönderir
    engine.process_step_1_client_syn(TCPPacket(src_port=1234, dst_port=80, seq=1000, ack=0, flags=["SYN"]))
    # 2. Adım Hatalı: Beklenen ACK 1001 iken sunucu 9999 döner
    bad_syn_ack = TCPPacket(src_port=80, dst_port=1234, seq=5000, ack=9999, flags=["SYN", "ACK"])
    # Hata fırlatılmalıdır
    with pytest.raises(TCPValidationError):
        # İşlem denenir
        engine.process_step_2_server_syn_ack(bad_syn_ack)


def test_handshake_step3_invalid_ack_number_rejected():
    """İstemcinin 3. adımda gönderdiği ACK numarası (ISN_s + 1) ile eşleşmediğinde reddedildiğini test eder."""
    # Motor oluşturulur
    engine = TCPHandshakeEngine()
    # 1. Adım: ISN_c = 1000
    engine.process_step_1_client_syn(TCPPacket(src_port=1234, dst_port=80, seq=1000, ack=0, flags=["SYN"]))
    # 2. Adım: ISN_s = 5000, ACK = 1001
    engine.process_step_2_server_syn_ack(TCPPacket(src_port=80, dst_port=1234, seq=5000, ack=1001, flags=["SYN", "ACK"]))
    # 3. Adım Hatalı: Beklenen ACK 5001 iken istemci 7777 döner
    bad_ack = TCPPacket(src_port=1234, dst_port=80, seq=1001, ack=7777, flags=["ACK"])
    # Hata fırlatılmalıdır
    with pytest.raises(TCPValidationError):
        # İşlem denenir
        engine.process_step_3_client_ack(bad_ack)


def test_handshake_step3_with_syn_flag_rejected():
    """3. adımda istemcinin gönderdiği pakette SYN bayrağının bulunması durumunda reddedildiğini test eder."""
    # Motor oluşturulur
    engine = TCPHandshakeEngine()
    # 1. Adım: ISN_c = 1000
    engine.process_step_1_client_syn(TCPPacket(src_port=1234, dst_port=80, seq=1000, ack=0, flags=["SYN"]))
    # 2. Adım: ISN_s = 5000, ACK = 1001
    engine.process_step_2_server_syn_ack(TCPPacket(src_port=80, dst_port=1234, seq=5000, ack=1001, flags=["SYN", "ACK"]))
    # 3. Adım Hatalı: İstemci hem SYN hem ACK bayrağı taşır
    bad_pkt = TCPPacket(src_port=1234, dst_port=80, seq=1001, ack=5001, flags=["SYN", "ACK"])
    # Hata fırlatılmalıdır
    with pytest.raises(TCPValidationError):
        # 3. adım denenir
        engine.process_step_3_client_ack(bad_pkt)


def test_syn_cookie_generation_and_verification():
    """Kriptografik SYN Cookie üretimi ve onay doğrulama mekanizmasını test eder."""
    # Motor nesnesi oluşturulur
    engine = TCPHandshakeEngine(secret_key=b"TestGizliAnahtar123")
    # Bağlantı 4'lüsü
    src_ip, src_port, dst_ip, dst_port = "192.168.1.100", 55555, "10.0.0.1", 80
    
    # Sunucu durumsuz SYN Cookie üretir
    cookie = engine.generate_syn_cookie(src_ip, src_port, dst_ip, dst_port, mss_idx=2)
    # Cookie 32-bitlik bir tamsayı olmalıdır
    assert 0 <= cookie <= 0xFFFFFFFF

    # İstemciden dönen ACK paketinde onay değeri (cookie + 1) olur
    client_ack = (cookie + 1) & 0xFFFFFFFF
    # Doğrulama fonksiyonu çalıştırılır
    is_valid = engine.verify_syn_cookie(client_ack, src_ip, src_port, dst_ip, dst_port)
    # Doğrulama başarılı olmalıdır (True)
    assert is_valid is True

    # Sahte veya değiştirilmiş bir ACK değeri (cookie + 999) denenir
    fake_ack = (cookie + 999) & 0xFFFFFFFF
    # Sahte ACK doğrulamadan geçmemelidir (False)
    assert engine.verify_syn_cookie(fake_ack, src_ip, src_port, dst_ip, dst_port) is False


def test_syn_flood_backlog_overflow_detection():
    """Yarım açık bağlantı kuyruk sınırı aşıldığında SYN Flood alarmının tetiklendiğini test eder."""
    # Kuyruk sınırı 2 olan denetleyici başlatılır
    auditor = TCPSecurityAuditor(backlog_limit=2)
    
    # 1. İstek eklenir (Alarm oluşmamalı)
    a1 = auditor.record_syn_request("10.0.0.1", 1001)
    # Alarm None olmalıdır
    assert a1 is None

    # 2. İstek eklenir (Limit doldu, henüz aşılmadı)
    a2 = auditor.record_syn_request("10.0.0.2", 1002)
    # Alarm None olmalıdır
    assert a2 is None

    # 3. İstek eklenir (Limit aşıldı: 3 > 2)
    a3 = auditor.record_syn_request("10.0.0.3", 1003)
    # Alarm üretilmelidir
    assert a3 is not None
    # Kategori SYN_FLOOD_SALDIRISI olmalıdır
    assert a3["kategori"] == "SYN_FLOOD_SALDIRISI"
    # Seviye KRITIK olmalıdır
    assert a3["seviye"] == "KRITIK"


def test_isn_predictability_detection():
    """Tahmin edilebilir (lineer artan) ISN dizisinde güvenlik alarmı üretildiğini test eder."""
    # Sabit 1000'er artan zafiyetli ISN dizisi
    vulnerable_isns = [100000, 101000, 102000, 103000, 104000]
    # Denetim fonksiyonu çalıştırılır
    alert = TCPSecurityAuditor.audit_isn_predictability(vulnerable_isns)
    # Alarm üretilmiş olmalıdır
    assert alert is not None
    # Kategori TAHMIN_EDILEBILIR_ISN_ZAFİYETI olmalıdır
    assert alert["kategori"] == "TAHMIN_EDILEBILIR_ISN_ZAFİYETI"
    # Sabit artış miktarı 1000 olmalıdır
    assert alert["sabit_artis"] == 1000


def test_isn_random_entropy_passes():
    """Rastgele ve güvenli üretilmiş ISN dizisinin zafiyet üretmeden geçtiğini test eder."""
    # Kriptografik PRNG ile üretilmiş rastgele dizi
    random_isns = [89234123, 234125, 412390823, 98234, 5512398]
    # Denetim koşulur
    alert = TCPSecurityAuditor.audit_isn_predictability(random_isns)
    # Zafiyet bulunmamalıdır (None)
    assert alert is None


def test_comprehensive_handshake_analysis_json():
    """Örnek JSON dosyasını okuyarak Markdown raporunun eksiksiz derlendiğini test eder."""
    # Dosya yolu belirlenir
    json_path = os.path.join(os.path.dirname(__file__), "..", "ornek_veri", "sample_tcp_handshakes.json")
    # Analiz çalıştırılır
    report = run_comprehensive_handshake_analysis(json_path)
    # Rapor başlığı içermelidir
    assert "TCP Üçlü El Sıkışma" in report
    # Özel lisans uyarısını içermelidir
    assert "ÖZEL LİSANS — TÜM HAKLAR SAKLIDIR" in report
    # Durum makinesi başarısını içermelidir
    assert "ESTABLISHED" in report
    # SYN Flood uyarısını içermelidir
    assert "SYN_FLOOD_SALDIRISI" in report
    # Şüpheli bayrak uyarısını içermelidir
    assert "XMAS_SCAN_SUSPICION" in report
    # ISN uyarısını içermelidir
    assert "TAHMIN_EDILEBILIR_ISN_ZAFİYETI" in report
