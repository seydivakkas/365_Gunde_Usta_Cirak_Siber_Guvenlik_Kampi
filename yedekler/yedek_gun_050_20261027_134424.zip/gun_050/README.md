# Gün 050: TCP Üçlü El Sıkışma (3-Way Handshake) ve Güvenlik Analizi

![License: All Rights Reserved](https://img.shields.io/badge/license-All%20Rights%20Reserved-red?style=flat-square)

Bu çalışma, Siber Güvenlik 365 Günlük Müfredatı kapsamında Aşama 03 (Ağ Temelleri ve Ağ Güvenliği), Hafta 08, Gün 050 çalışmasıdır.

---

## 📋 Proje Özeti

Katman-4 Taşıma Katmanı'nda güvenilir iletişimin temeli olan TCP (RFC 793/RFC 9293) üçlü el sıkışma mekanizmasını, durum makinesi (State Machine) geçişlerini, 32-bitlik sıra ve onay (SEQ/ACK) matematiğini, kural dışı bayrak kombinasyonlarını (NULL, XMAS, SYN-FIN), SYN Flood DoS saldırılarını ve RFC 4987 standartlarında durumsuz (stateless) SYN Cookie savunma mimarisini modelleyen kapsamlı laboratuvar paketidir.

### Temel Özellikler
- **TCP Durum Makinesi:** İstemci ve sunucu durum geçişleri (`CLOSED -> SYN_SENT -> SYN_RECEIVED -> ESTABLISHED`) adım adım simüle edilir.
- **Sıra ve Onay Numaraları Doğrulaması:** 32-bit ISN üretimi, SYN bayrağının sanal 1 bayt tüketimi ve `ACK = ISN + 1` matematiksel doğrulaması.
- **Kural Dışı Bayrak ve Tarama Tespiti:**
  - `NULL Scan`: Hiçbir bayrak aktif değil.
  - `XMAS Scan`: FIN, PSH ve URG aynı anda aktif.
  - `SYN + FIN` & `SYN + RST`: Çelişkili ve geçersiz bayrak kombinasyonları.
- **SYN Flood ve DoS Simülasyonu:** Yarım açık bağlantı (Half-Open) kuyruk taşması tespiti.
- **Kriptografik SYN Cookies:** HMAC-SHA256 ile durumsuz cookie üretimi ve dönüş ACK onayının doğrulanması.
- **Satır Satır Açıklamalı Kod:** Uygulama ve test kodlarının tamamı didaktik açıklamalarla zenginleştirilmiştir.

---

## 📂 Dizin Yapısı

```
portfolio/hafta_08/gun_050/
├── README.md                                    # Modül dokümantasyonu ve çalıştırma kılavuzu
├── ders.md                                      # Usta-Çırak pedagojisiyle hazırlanmış TCP dersi
├── soru_cevap.md                                # Soru bankası (G050-SC1/2/3) 4 başlıklı cevapları
├── rapor.md                                     # 100/100 rubrik değerlendirme ve teknik rapor
├── sonuc.json                                   # Gün sonu standart makine çıktısı
├── manifest.json                                # SHA-256 doğruluk ve bütünlük tablosu
├── uygulama/
│   ├── __init__.py                              # Paket başlatıcı
│   └── tcp_handshake_analyzer.py                # TCP el sıkışma motoru ve güvenlik denetleyicisi
├── tests/
│   ├── __init__.py                              # Test paketi başlatıcı
│   └── test_tcp_handshake_analyzer.py           # 14 birim testi ve güvenlik doğrulamaları
├── ornek_veri/
│   ├── sample_tcp_handshakes.json               # 4 farklı oturum ve güvenlik senaryosu
│   └── invalid_tcp_packets.json                 # 8 geçersiz girdi ve biçim hata senaryosu
└── kanit/
    ├── gercek/
    │   ├── test_sonuclari.txt                   # pytest 14/14 PASS kanıtı
    │   ├── komut_ve_cikis.txt                   # Konsol yürütme çıktısı
    │   ├── tcp_el_sikisma_raporu.txt            # Üretilen Markdown analiz raporu
    │   └── negatif_kontrol_sonuclari.txt        # 8 negatif vakanın yakalanma raporu
    └── temsili/
        └── tcp_handshake_ve_syn_flood_mimarisi.txt # El sıkışma, SYN Flood ve Cookie şeması
```

---

## 🚀 Hızlı Başlangıç ve Çalıştırma

### 1. TCP El Sıkışma Analizörünü Çalıştırma
```powershell
python portfolio/hafta_08/gun_050/uygulama/tcp_handshake_analyzer.py
```

### 2. Birim ve Güvenlik Testlerini Koşma
```powershell
pytest portfolio/hafta_08/gun_050/tests/test_tcp_handshake_analyzer.py -v
```

---

## 🔒 Lisans Kuralı

```
ÖZEL LİSANS — TÜM HAKLAR SAKLIDIR

Telif Hakkı (c) 2026 Seydi Eryılmaz (@seydivakkas)

Bu yazılım ve ilgili tüm dosyalar ("Yazılım") yalnızca görüntüleme ve eğitim
amaçlı olarak paylaşılmıştır.

YASAKLAR:
  1. Kopyalanamaz, çoğaltılamaz, dağıtılamaz veya yeniden yayınlanamaz.
  2. Ticari veya ticari olmayan hiçbir projede kullanılamaz, değiştirilemez.
  3. Alt lisanslanamaz, satılamaz veya devredilemez.
  4. Tersine mühendislik yapılamaz.

İZİN VERİLEN KULLANIM:
  - GitHub üzerinde görüntüleme ve okuma.
  - Kişisel öğrenim amacıyla kodu inceleme (kopyalamadan).

YAZARIN AÇIK YAZILI İZNİ OLMAKSIZIN HİÇBİR KULLANIM HAKKI TANINMAZ.
İzin talepleri için: GitHub @seydivakkas
```
