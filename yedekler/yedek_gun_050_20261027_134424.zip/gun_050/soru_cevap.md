# Gün 050: Soru-Cevap ve Kavramsal Pekiştirme

**ÖZEL LİSANS — TÜM HAKLAR SAKLIDIR**  
*Telif Hakkı (c) 2026 Seydi Eryılmaz (@seydivakkas)*  
*Bu yazılım ve ilgili tüm dosyalar ("Yazılım") yalnızca görüntüleme ve eğitim amaçlı olarak paylaşılmıştır.*

---

## Soru 1 (G050-SC1): TCP Üçlü El Sıkışma Mekanizması ve Güvenlik Önemi

### Temel Mekanizma ve Güvenlik Önemi
TCP üçlü el sıkışma (3-Way Handshake - RFC 793/RFC 9293), güvenilmez IP katmanı üzerinde güvenilir, çift yönlü (full-duplex) ve sıralı bir veri aktarım kanalı kurmak için işletilen durum makinesidir:
1. **Sıra Numarası Eşitlemesi (Synchronization):** İstemci ve sunucu kendi başlangıç sıra numaralarını (ISN_c ve ISN_s) birbirine ilan eder. Her TCP paketi uygulama verisi taşımaz; el sıkışma aşamasındaki SYN, SYN-ACK ve ACK paketlerinin yükü (payload) sıfır bayttır. Ancak SYN bayrağı sıra numarası uzayında 1 sanal bayt tüketir; bu sebeple onay numaraları (ACK) her zaman `ISN + 1` olarak hesaplanır.
2. **Hayalet Bağlantıların ve Gecikmiş Paketlerin Engellenmesi:** İki adımlı bir el sıkışma yerine üç adımın zorunlu kılınması, ağda gecikmiş eski SYN paketlerinin sunucuda tek taraflı oturum açmasını ve kaynak tüketmesini engeller.
3. **Güvenlik Boyutu:** TCP oturumunun ilk saniyeleri, bağlantının güvenilirliğini belirler. Başlangıç sıra numarasının (ISN) tahmin edilebilir olması kör oturum çalma (Blind TCP Hijacking) açıklarına, yarım açık bağlantıların yönetilememesi ise SYN Flood DoS felaketlerine zemin hazırlar.

### Bağımsız Laboratuvar ve Doğrulama Adımları
- **Girdi:** `portfolio/hafta_08/gun_050/ornek_veri/sample_tcp_handshakes.json` dosyasında yer alan 4 farklı senaryo (standart HTTP/HTTPS el sıkışması, SYN Flood DoS simülasyonu, kural dışı tarama prob paketleri ve tahmin edilebilir ISN serisi).
- **İşlem:**
  1. `TCPPacket` sınıfı ile 16-bit port, 32-bit SEQ/ACK ve TCP bayrakları doğrulanır.
  2. `TCPHandshakeEngine` durum makinesi işletilerek `CLOSED -> SYN_SENT -> SYN_RECEIVED -> ESTABLISHED` geçişleri doğrulanır.
  3. `TCPSecurityAuditor` motoru ile yarım açık kuyruk derinliği taranır ve kural dışı bayraklar analiz edilir.
  4. Durumsuz `generate_syn_cookie` ve `verify_syn_cookie` fonksiyonları ile SYN Cookie koruması test edilir.
- **Beklenen Çıktı:** 14 birim testin tamamının `PASSED` olması; meşru oturumun `ESTABLISHED` durumuna ulaşması; SYN Flood ve XMAS/NULL tarama alarmlarının üretilmesi.
- **Negatif Kontrol:** Port > 65535, SEQ > 4294967295, negatif ACK, geçersiz bayrak adı ve 1. adımda ACK içeren paketlerin `TCPValidationError` ile engellenmesi.

### Risk Analizi ve Tehdit Senaryoları
- **SYN Flood Saldırısı:** Saldırganın sahte IP adresleriyle hedef sunucuya binlerce SYN gönderip asla son ACK'yı atmaması sonucu sunucunun SYN Backlog kuyruğunun dolması ve meşru istemcilerin kapıda kalması.
- **Tahmin Edilebilir ISN ile Kör Komut Enjeksiyonu:** ISN değerlerinin kriptografik rastgelelik içermemesi durumunda saldırganın güvenilen bir istemci gibi davranarak TCP akışına sahte komutlar enjekte etmesi (Kevin Mitnick saldırı tipi).
- **Kural Dışı Bayrak Probları (XMAS/NULL/SYN-FIN):** Güvenlik duvarlarının durum tablosunu şaşırtarak iç ağdaki açık portları haritalandırma girişimleri.

### Tespit Sinyalleri ve Önleme Kontrolleri
- **Tespit:**
  1. `netstat -ant | grep SYN_RECV` komutunda aşırı sayıda bağlantı görülmesi.
  2. SIEM ve IDS üzerinde kısa sürede tek bir hedefe yönelik aşırı SYN bayraklı paket akışının loglanması.
- **Önleme:**
  1. **SYN Cookies (RFC 4987):** Çekirdekte `sysctl -w net.ipv4.tcp_syncookies=1` yapılandırmasıyla durumsuz savunmanın aktif edilmesi.
  2. **Kriptografik ISN (RFC 6528):** İşletim sistemlerinde CSPRNG destekli sıra numarası üretiminin zorunlu kılınması.
  3. **Stateful Firewall & Normalization:** Kural dışı bayrak taşıyan segmentlerin ağ sınırında anında çöpe atılması.

---

## Soru 2 (G050-SC2): Bağımsız Laboratuvarın Girdisi, İşlemi, Beklenen Sonucu ve Negatif Kontrolü

### Temel Mekanizma ve Güvenlik Önemi
Katman-4 taşıma katmanı analiz motorları, canlı işletim sistemi ham soketlerine (raw socket) veya yönetici izinlerine ihtiyaç duymadan, sentetik ve matematiksel olarak TCP başlıklarını, bayrak maskelerini ve durum geçişlerini doğrulayabilmelidir.

### Bağımsız Laboratuvar ve Doğrulama Adımları
- **Girdi:** 
  1. `sample_tcp_handshakes.json`: 3 adımlı geçerli oturum, 5 sahte SYN isteği, 4 kural dışı prob paketi ve 5 elemanlı tahmin edilebilir ISN dizisi.
  2. `invalid_tcp_packets.json`: 8 adet geçersiz sınır ihlali senaryosu.
- **İşlem:**
  1. `TCPFlags.encode_flags` ve `decode_flags` ile 8-bitlik bayrak matematiği denetlenir.
  2. İstemci `process_step_1_client_syn` çağrısı yapar (SEQ=1005001, ACK=0).
  3. Sunucu `process_step_2_server_syn_ack` çağrısı yapar (SEQ=5002001, ACK=1005002).
  4. İstemci `process_step_3_client_ack` çağrısı yapar (SEQ=1005002, ACK=5002002).
  5. Oturumun `ESTABLISHED` durumuna ulaştığı teyit edilir.
- **Beklenen Çıktı:** 14 birim testin 0.03 saniyede hatasız tamamlanması; Markdown raporunda durum tablolarının ve alarmların eksiksiz yer alması (`kanit/gercek/tcp_el_sikisma_raporu.txt`).
- **Negatif Kontrol:** 8 farklı geçersiz girdinin (port > 65535, SEQ taşması, negatif ACK, tanımsız bayrak, hatalı IP formatı, boş paket, eksik zorunlu alan, pencere > 65535) tamamının `TCPValidationError` fırlatması ve `kanit/gercek/negatif_kontrol_sonuclari.txt` dosyasına kaydedilmesi.

### Risk Analizi ve Tehdit Senaryoları
Yetersiz girdi ve durum doğrulama:
- Sunucunun sıra dışı (out-of-order) veya hatalı ACK içeren paketleri kabul etmesi, oturumun saldırgan tarafından sıfırlanmasına (RST Injection) veya bağlantı kilitlenmesine yol açar.

### Tespit Sinyalleri ve Önleme Kontrolleri
- **Tespit:** Wireshark veya `tshark -Y "tcp.analysis.flags"` filtresi ile yeniden iletimlerin (retransmissions) ve geçersiz sıra numaralı paketlerin taranması.
- **Önleme:** TCP yığınında katı RFC 9293 durum doğrulamasının uygulanması.

---

## Soru 3 (G050-SC3): Risk Oluşumu, Tespiti ve Savunma Kontrolleri

### Temel Mekanizma ve Güvenlik Önemi
TCP bağlantı kurulumundaki zayıflıklar, doğrudan işletim sistemi çekirdeğinin bellek yönetimini hedef alır. Katman-7 uygulama seviyesinde hiçbir açık olmasa dahi, Katman-4'teki bir SYN Flood saldırısı web sunucusunu erişilemez hale getirebilir.

### Bağımsız Laboratuvar ve Doğrulama Adımları
Laboratuvarımızda bu tehditler kod düzeyinde modellenmiş ve önleme mekanizmaları doğrulanmıştır:
1. **SYN Flood Simülasyonu:** `TCPSecurityAuditor` üzerinde backlog limiti aşıldığında `SYN_FLOOD_SALDIRISI` alarmı üretilmiş ve kuyruk derinliği raporlanmıştır.
2. **SYN Cookie Mekanizması:** Sunucunun bellekte durum saklamadan 4-tuple ve zaman damgasını HMAC-SHA256 ile özetleyip istemciye SEQ olarak döndüğü; istemcinin dönüş ACK'sından orijinal anahtarın başarıyla doğrulandığı kanıtlanmıştır.
3. **Kural Dışı Bayrak Tespiti:** `audit_flag_anomalies` fonksiyonu ile `SYN+FIN`, `XMAS` ve `NULL` taramaları başarıyla yakalanmıştır.

### Risk Analizi ve Tehdit Senaryoları
- **TCP TCB Bellek Boğulması:** Çok kullanıcılı sunucularda her yarım açık bağlantı yaklaşık 280-350 bayt çekirdek belleği (Kernel Socket Buffer) tutar. Yüz binlerce sahte SYN isteği işletim sistemi çekirdeğinde Out-Of-Memory (OOM) krizine neden olur.
- **Güvenlik Duvarı Durum Tablosu Taşması:** Güvenlik duvarları her TCP oturumu için bir State Table kaydı açar. SYN Flood yalnızca sunucuyu değil, aradaki pahalı kurumsal güvenlik duvarlarını da çökertebilir.

### Tespit Sinyalleri ve Önleme Kontrolleri
- **Tespit:**
  1. Sunucuda `SYN_RECV` sayısının `ESTABLISHED` sayısından 10 kat fazla olması.
  2. Güvenlik duvarlarında `drop invalid tcp state` sayaçlarının hızla yükselmesi.
- **Önleme:**
  1. **SYN Cache ve SYN Cookies:** Çekirdek seviyesinde kuyruk taşmasını önleyen en temel standart kalkan.
  2. **TCP Rate Limiting:** Tek bir kaynak IP veya alt ağdan saniyede gelebilecek SYN istek sayısının sınırlandırılması (`iptables -m limit --limit 20/s`).
  3. **TCP MSS ve Pencere Sıkılaştırma:** Sınır yönlendiricilerde olağandışı küçük MSS veya pencere boyutu içeren paketlerin normalize edilmesi.
