# Gün 050: Teknik Değerlendirme ve Uygulama Raporu

**ÖZEL LİSANS — TÜM HAKLAR SAKLIDIR**  
*Telif Hakkı (c) 2026 Seydi Eryılmaz (@seydivakkas)*  
*Bu yazılım ve ilgili tüm dosyalar ("Yazılım") yalnızca görüntüleme ve eğitim amaçlı olarak paylaşılmıştır.*

---

## 1. Çalışma Özeti ve Görev Kapsamı

Bu çalışma, Aşama 03 (Ağ Temelleri ve Ağ Güvenliği) 8. Hafta 50. Gün müfredatında yer alan **"TCP Üçlü El Sıkışma"** konusunu kapsar. Gerçekleştirilen çalışmalar:
- **RFC 793 ve RFC 9293 Durum Makinesi Modellemesi:**
  - İstemci ve sunucu arasındaki üç adımlı bağlantı kurulumu (`SYN -> SYN-ACK -> ACK`) ikili bayrak ve sayaç seviyesinde modellenmiştir.
  - Durum geçişleri (`CLOSED -> SYN_SENT -> SYN_RECEIVED -> ESTABLISHED`) adım adım simüle edilmiş ve sıra dışı paketler engellenmiştir.
- **Sıra ve Onay Numaraları (SEQ / ACK) Matematiği:**
  - 32-bitlik Başlangıç Sıra Numaraları (ISN_c ve ISN_s) hesaplanmış; SYN bayrağının 1 sanal bayt tüketme kuralı işletilerek `ACK = ISN + 1` doğrulaması yapılmıştır.
- **Kural Dışı Bayrak ve Port Tarama Tespiti:**
  - `NULL Scan` (0 bayrak), `XMAS Scan` (FIN+PSH+URG), `SYN+FIN` ve `SYN+RST` çelişkili kombinasyonları tespit eden kural motoru yazılmıştır.
- **Güvenlik Tehditleri ve Savunma Mekanizmaları:**
  - `SYN Flood Saldırısı`: Yarım açık bağlantı kuyruk derinliği takip edilmiş ve taşma anında `SYN_FLOOD_SALDIRISI` alarmı tetiklenmiştir.
  - `SYN Cookies (RFC 4987)`: HMAC-SHA256 tabanlı durumsuz cookie üretimi ve dönüş onayında matematiksel doğrulama motoru sıfırdan kodlanmıştır.
  - `Tahmin Edilebilir ISN Analizi`: Doğrusal artan ISN dizilerindeki sıra numarası tahmin zafiyeti (Kevin Mitnick saldırı vektörü) tespit edilmiştir.
- 14 birim testi ve 8 negatif kontrol senaryosu hazırlanmış; tümü başarıyla tamamlanmıştır.

---

## 2. Değerlendirme Rubriği ve Puanlama

| Kriter No | Değerlendirme Boyutu | Ağırlık / Tam Puan | Alınan Puan | Açıklama ve Gerekçe |
|---|---|---|---|---|
| **1** | Kavramsal Derinlik | 20 | **20** | Katman-4 taşıma güvencesi, RFC 793/9293 durum makinesi, 3 adımın gerekliliği, SEQ/ACK matematiği, SYN Flood ve SYN Cookies mantığı usta-çırak pedagojisiyle derinlemesine aktarıldı. |
| **2** | Uygulama Geliştirme | 40 | **40** | `tcp_handshake_analyzer.py` modülü sıfırdan geliştirildi; her kod satırı didaktik açıklamalarla zenginleştirildi; durum makinesi, HMAC SYN Cookie motoru ve Markdown raporlayıcı hatasız çalıştı. |
| **3** | Test Kapsamı ve Doğrulama | 25 | **25** | `test_tcp_handshake_analyzer.py` altında 14 birim testi hazırlandı; pytest ile 14/14 PASS elde edildi; 8 negatif kontrol senaryosu başarıyla engellendi ve kanıtlandı. |
| **4** | Savunma ve Sıkılaştırma | 15 | **15** | SYN Cookies çekirdek parametreleri (`net.ipv4.tcp_syncookies`), RFC 6528 CSPRNG ISN üretimi, Stateful Firewall ve TCP normalizasyon ilkeleri kapsamlıca belgelendi. |
| **TOPLAM** | **Genel Performans** | **100** | **100** | **DURUM: YETERLİ / PASS** |

---

## 3. Test ve Doğrulama Kanıtları Özeti

- **Birim Testleri (`kanit/gercek/test_sonuclari.txt`):**
  - Toplam Test: 14
  - Başarılı: 14 (100%)
  - Hatalı / Kırılan: 0
  - Yürütme Süresi: 0.03 saniye
- **Uygulama Çalıştırma Kanıtı (`kanit/gercek/komut_ve_cikis.txt` & `kanit/gercek/tcp_el_sikisma_raporu.txt`):**
  - Meşru oturum `ESTABLISHED` durumuna ulaştı; SYN Flood saldırısında kuyruk taşması yakalandı; 4 adet kural dışı tarama probu ve tahmin edilebilir ISN serisi başarıyla alarmlandı.
- **Negatif Kontrol Kanıtı (`kanit/gercek/negatif_kontrol_sonuclari.txt`):**
  - 8 geçersiz girdi biçimi (port > 65535, SEQ taşması, negatif ACK, tanımsız bayrak adı, geçersiz IP, boş paket, eksik alan, pencere boyutu taşması) `TCPValidationError` istisnası ile başarıyla yakalandı ve engellendi.
- **Kavramsal Mimari Şeması (`kanit/temsili/tcp_handshake_ve_syn_flood_mimarisi.txt`):**
  - Zorunlu `TEMSİLÎ — AI İLLÜSTRASYONU — GERÇEK TEST DEĞİL` başlığı altında standart el sıkışma akışı, SYN Flood kuyruk tüketimi ve RFC 4987 SYN Cookie savunma duvarı görselleştirildi.

---

## 4. Güvenlik ve Savunma Çıkarımları

1. **Katman-4 TCB Bellek Koruması Hayatidir:** Uygulama seviyesinde ne kadar güçlü güvenlik olursa olsun, çekirdek seviyesinde SYN Flood koruması (SYN Cookies) aktif değilse sistem kolayca hizmet dışı bırakılabilir.
2. **Kriptografik ISN Üretimi Zorunludur:** Başlangıç sıra numaraları tahmin edilebilir olan sunucularda saldırganlar araya girmeden (blind attack) sahte TCP segmentleri enjekte edebilir.
3. **Kural Dışı Bayraklar Sınırda Engellenmelidir:** SYN+FIN, NULL ve XMAS gibi anomali taşıyan segmentler sınır güvenlik duvarında normalize edilerek iç ağa girmeden düşürülmelidir.

---

## 5. Sonuç ve Onay

Gün 050 kapsamındaki tüm teorik, uygulamalı, test ve güvenlik gereksinimleri eksiksiz olarak tamamlanmış, tüm kanıtlar yerel olarak üretilmiş ve doğrulanmıştır. 8. Haftanın ilk günü tam başarıyla tamamlanmıştır.

- **Nihai Karar:** `PASS`
- **Genel Not:** 100 / 100
